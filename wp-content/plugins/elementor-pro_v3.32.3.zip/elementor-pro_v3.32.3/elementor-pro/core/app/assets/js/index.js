import Module from '../../modules/site-editor/assets/js/site-editor';
import ImportExportCustomizationModule from '../../modules/import-export-customization/assets/js/module';

new Module();
new ImportExportCustomizationModule();
