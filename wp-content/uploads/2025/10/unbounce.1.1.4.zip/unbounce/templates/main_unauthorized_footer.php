<a href="https://documentation.unbounce.com/hc/en-us/articles/360000393623-Troubleshooting-WordPress-Plugin-Technical-Issues"
   target="_blank">Check out our knowledge base.</a>
<br/>
<a class="ub-diagnostics-link" href="<?php echo admin_url('admin.php?page='.UBConfig::UB_ADMIN_PAGE_DIAGNOSTICS); ?>">
  Click here for troubleshooting and plugin diagnostics
</a>
<p class="ub-version">Unbounce Version 1.1.4</p>
