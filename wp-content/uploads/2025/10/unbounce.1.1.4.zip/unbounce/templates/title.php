<img class="ub-logo" src="<?php echo plugins_url('img/unbounce-logo-white.png', dirname(__FILE__)); ?>" />
<h1><?php echo esc_html(get_admin_page_title()); ?></h1>
