<div class="edgtf-tab-container" id="tab-<?php echo sanitize_title($tab_title); ?>"><?php echo do_shortcode($content); ?></div>
