<?php

include_once PLAYERX_CORE_SHORTCODES_PATH . '/contact-form-7/functions.php';
