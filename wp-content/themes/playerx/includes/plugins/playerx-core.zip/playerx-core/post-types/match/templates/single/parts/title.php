<div class="edgtf-match-info-item">
	<h4 class="edgtf-match-item-title"><?php the_title(); ?></h4>

    <?php playerx_core_match_get_info_part('result'); ?>

</div>