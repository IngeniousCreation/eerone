<div class="edgtf-match-item-content">
    <?php the_content(); ?>
</div>